export interface IAnswerRow {
  text: string;
  language?: number;
  correct: boolean;
  userAnswer?: boolean;
}
