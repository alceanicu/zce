export interface IQuestionRow {
  text: string;
  language?: number;
}
