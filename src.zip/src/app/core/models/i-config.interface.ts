export interface IConfig {
  counter: number;
  timestamp: number;
}
