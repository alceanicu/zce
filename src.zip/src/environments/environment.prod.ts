export const environment = {
  production: false,
  phpPath: 'phpQuestions',
  configPath: 'appConfig',
  firebase: {
    apiKey: 'AIzaSyCPo9FJxt-5zsARU-Br-9MOSVs0CJoEOsQ',
    authDomain: 'php-alma-test.firebaseapp.com',
    databaseURL: 'https://php-alma-test.firebaseio.com',
    projectId: 'php-alma-test',
    storageBucket: 'php-alma-test.appspot.com',
    messagingSenderId: '486664010402'
  },
  apiUrl: 'http://localhost/rest-api/',
  extensionsAllowed: ['sql', 'php', 'none', 'html', 'xml', 'json']
};
